package com.example.tugasmobile;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    ImageView gambar3;
    TextView text2, text3, text4, text5, text6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView gambar3 = (ImageView) findViewById(R.id.gambar3);

        text2 = (TextView) findViewById(R.id.text2);
        text2.setText("NPM: 16411035");

        text3 = (TextView) findViewById(R.id.text3);
        text3.setText("Nama: Govinda Fajar Hidayatullah");

        text4 = (TextView) findViewById(R.id.text4);
        text4.setText("TTL:Bandar Lampung, 19 Maret 1998");

        text5 = (TextView) findViewById(R.id.text5);
        text5.setText("Alamat: Jl. Imam Bonjol Gg sultan anom Bandar Lampung");

        text6 = (TextView) findViewById(R.id.text6);
        text6.setText("Hobi: Apa aja dijadiin hobi");

    }
}
